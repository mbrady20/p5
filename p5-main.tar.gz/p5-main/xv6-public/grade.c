/**
 * Please do not modify this file. 
 * This file will be replaced when grading. 
*/

#include "param.h"
#include "types.h"
#include "defs.h"
#include "mmu.h"
#include "proc.h"

void log_sched(struct proc* p) {}
